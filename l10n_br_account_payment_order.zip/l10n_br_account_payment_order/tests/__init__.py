# @ 2018 Akretion - www.akretion.com.br -
#   Magno Costa <magno.costa@akretion.com.br>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html)

from . import test_base_class
from . import test_invoice_normal_workflow
from . import test_payment_order
from . import test_payment_order_inbound
from . import test_payment_order_change
from . import test_invoice_manual_workflow
from . import test_payment_mode
